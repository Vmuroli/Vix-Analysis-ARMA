clear; clc;

%% first of all we need to import the datas

VIX=importdata("^VIX.csv");
INSAMPLE=VIX.data(1:6749,5);           %we split the importing into the in-sample, till 11 oct and out-of-sample, from 11 to 31 oct
OUTOFSAMPLE=VIX.data(6750:end,5);

dates=VIX.textdata(2:end,1);       
date=datetime(dates);              
figure
plot(date,[INSAMPLE;OUTOFSAMPLE]);        % for completeness we import also the vector date and plot the behavior of the series
title('VIX from the downloaded datas')
%% adjusting the datas and testing for stationarity

in_s=diff(log((INSAMPLE)));
t=size(in_s,1);
[~,pValue_adf,stat_adf] = adftest(in_s); 
[~,pValue_pp,stat_pp] = pptest(in_s);
[~,pValue_kpss,stat_kpss] = kpsstest(in_s);
%% 
% to check what is the model with lowest bic i construct a loop with the
% functions arima and estimate to put all bic in a matrix and select the
% one with lowest value, associated with the number of legs in ar and ma
% model

logl=zeros(4,4);
pq=zeros(4,4);
for p=1:4;
    for q=1:4;
        mod=arima(p,0,q);
        [fit,~,logL]=estimate(mod,in_s,'Display','off');
        logl(p,q)=logL;
        pq(p,q)=p+q;
    end
end

logl2=reshape(logl,16,1);
pq2=reshape(pq,16,1);
[~,bic]=aicbic(logl2,pq2+1,t);
bic2=reshape(bic,4,4);

%% 
%from the test with bic matrix we found that the optimal arma model is
%ARMA(1,1), so we proceed constructing the vector of log-likelihood and
%estimating the parameters

zeta0=[0;0;0;1];
lb=[-inf,-inf,-inf,eps]';
ub=ones(4,1).*inf;

[zeta_ll,~,~,logl_11]=Max_lik('logl_arma11',zeta0,'Hessian',[],[],[],[],lb,ub,[],[],in_s)

%% now that we chosed an optimal set of parameters we can operate some test on residuals

% the first one is to watch to autocorrelation of residuale to see wheather
% there are some peaks
[~,~,epsilon_11]=logl_arma11(zeta_ll,in_s);
figure
autocorr(epsilon_11);   % as we can see there are no significant peaks ( we give the one on 10th obs as a casual one)
title('Autocorrelogram of epsilon')
% second we can use the ljung box test to asses weather there are some
% significative autocorrelations in the residual

[~,pvalueLB]=lbqtest(epsilon_11);   % the pvalue is near the critical value, so we cannot see much from this

%% we proceed with JB test to assess the gaussianity of residuals

figure
histogram(epsilon_11,40)        % first of all we give a qualitative look to the shape of distribution of epsilon, as we can see it seems a normal a little bit skewned and not leptokurtic
title('Histogram of the rediduals')
JB=t/6 * (skewness(epsilon_11)^2 + (((kurtosis(epsilon_11)-3)^2)/4));
pvalueJB=1-chi2cdf(JB,2);

%%
figure
autocorr(epsilon_11.^2)     % as we can see the autocorrelogram shows that there can be some heteroskedasticity
title('Autocorrelogram of residual squared')
[~,pvalueLB2]=lbqtest(epsilon_11.^2);
JB2=t/6 * (skewness(epsilon_11.^2)^2 + (((kurtosis(epsilon_11.^2)-3)^2)/4));
pvalueJB2=1-chi2cdf(JB2,2);
[~,pvalue_white,df]=White_test(in_s(2:end),[in_s(1:end-1),epsilon_11(1:end-1)],ones(size(in_s,1)-1,1)); % we perform a white test for the heteroskedasticity of residual
%% forecasting

out_s=diff(log(OUTOFSAMPLE));


model= arima(1,0,1);
periods=12;
est_model = estimate(model,in_s);
[out_fore,XMSE] = forecast(est_model,periods,in_s);

%%
r=70;
out_for=[NaN(r-1,1);in_s(end);out_fore(2:end)];
ins_obs=[in_s(end-r+1:end);NaN(size(periods,1))];

CI_5=[NaN(r-1,1);in_s(end);out_fore-1.96*sqrt(XMSE)];
CI_95=[NaN(r-1,1);in_s(end);out_fore+1.96*sqrt(XMSE)];

figure
h1 = plot(ins_obs,'Color',[.7,.7,.7]);
hold on
h2 = plot(out_for,'b','LineWidth',2);
ci_95 = plot(CI_95,'r:','LineWidth',2);
ci_5 = plot(CI_5,'r:','LineWidth',2);
h3 = plot([NaN(r-1,1);in_s(end);out_s],'g','LineWidth',2);
legend([h1 h2 ci_95 h3],'Observed','Forecast','95% Confidence Interval','Out of sample observed','Location','NorthWest');
title(['Forecasts and Observed value with 95% Confidence Intervals'])
hold off