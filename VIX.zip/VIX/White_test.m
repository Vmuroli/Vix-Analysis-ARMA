function [test,pvalue,df]=White_test(y,X,Z);

% function: White heteroskedasticity test of the residuals of
% y=X*beta+epsilon

% inputs: y : dependent variable (Nx1 vector)
% inputs: X : explanatory variables (NxK1 matrix) . Only those regressors which are not deterministic (like intercepts, trends, dummies, etc).  
% inputs: Z : Deterministic variables (NxK2) included in the original
% regression (K1+K2=K)
N=size(X,1);
K1=size(X,2);

results=ols(y,[Z,X]); % first stage-regression
epsilon_hat=results.resid; % residuals from the first-stage regression
%% Now we generate the regressors of the auxiliary regression
Dim=K1*(K1-1)/2;  % Number of different cross-product elements 

if K1>1;
    W=zeros(N,Dim);             % Preallocate the matrix with the cross-products
    s=1;                        % set the counter for the columns of W
    for i=1:K1-1;
        for j=i+1:K1;           % only the distinct elements
            W(:,s)=X(:,i).*X(:,j);
            s=s+1;
        end;
    end;
else
    W=[];
end;
XX=[Z,X,X.^2,W];
P=cols(XX);
result_aux=ols(epsilon_hat.^2,XX);
% Compute the LM test as N*R^2;
test=N*result_aux.rsqr;
df=P-1; % degrees of
pvalue=1-chi2cdf(test,df);


