function [loglik,mi,epsilon]=logl_arma21(zeta,y);
c=zeta(1);  phi=zeta(2); theta=zeta(3); sigma2=zeta(4);
t=size(y,1);
epsilon=zeros(t,1);
mi=ones(t,1).*(c/(1-phi));
loglik=zeros(t,1);

for i=2:t;
    
    mi(i)=c+y(i-1)*phi(1)+theta*epsilon(i-1);
    epsilon(i)=y(i)-mi(i);
    loglik(i)=0.5*(-log(2*pi)-log(sigma2)-((epsilon(i)^2)/sigma2));

end

end 